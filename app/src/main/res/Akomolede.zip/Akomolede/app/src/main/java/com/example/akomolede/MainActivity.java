package com.example.akomolede;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the content of the activity to use the activity_main.xml layout file
        setContentView(R.layout.activity_main);

        //find the testview component to call intent on
        LinearLayout numberOneTextView = findViewById(R.id.number_one_text_view);


        //using anonymous inner class signature to implement the intent call
        numberOneTextView.setOnClickListener(
                new View.OnClickListener() {

                    //Implementing the onClick method when component is called
                    @Override
                    public void onClick(View view) {

                        //explicitly creating an intent to call another activity
                        Intent intent = new Intent(getApplicationContext(), YorubaAlphabetsActivity.class);
                        startActivity(intent);
                    }
                });

    }
}